/*
 * 	DESCRIPCION:
 * 	Implementacion de un Multi-Layer Perceptron con 1 capa oculta utilizando funcion sigmoide para la activacion
 *  de neuronas en la capa oculta y de salida y entrenamiento mediante el algoritmo de BackPropagation (BP)
 *
 * 	Creado el 01/04/2013
 *
 * 	Inteligencia Artificial II - Ingenieria en Mecatronica
 *  Facultad de Ingenieria - Universidad Nacional de Cuyo
 *
 *  Autor: Dr. Ing. Martin G. Marchetta
 *
 * */

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"
#include "time.h"
#include "mlp.h"

//Funcion de activacion capa oculta
double f(double x)
{
	return 1 / (1 + pow(M_E, -x));
}

//Derivada de la funcion de activacion de la capa oculta
double f_derivada(double x)
{
	//derivada: e^(-x) / (1 + e^(-x))^2
	return pow(M_E, -x) / ((1 + pow(M_E, -x)) * (1 + pow(M_E, -x)));
}

//Funcion de activacion de la capa de salida
double g(double x)
{
	return x;
}

//Derivada de la funcion de activacion de la capa de salida
double g_derivada(double x)
{
	return 1;
}

void calcula_salida_red(double Wji[NEURONAS_ENTRADA][NEURONAS_CAPA_OCULTA], double Wkj[NEURONAS_CAPA_OCULTA][NEURONAS_SALIDA], double x[NEURONAS_ENTRADA], double y[NEURONAS_CAPA_OCULTA], double z[NEURONAS_SALIDA])
{
	int i;
	int j;
	int k;
	double entrada_y;
	double entrada_z;

	//Inicializa salidas
	memset(z, 0, sizeof(double) * NEURONAS_SALIDA);

	//Calculamos salidas de la capa oculta
	for (j = 0; j < NEURONAS_CAPA_OCULTA; j++)
	{
		// Funcion de entrada
		entrada_y = 0;
		for (i = 0; i < NEURONAS_ENTRADA; i++)
		{
			entrada_y += Wji[i][j] * x[i];
		}

		//Sesgo neuronas capa oculta
		entrada_y -= Wji[NEURONAS_ENTRADA][j];

		// Valor de salida de la neurona oculta y_j
		y[j] = f(entrada_y);
	}

	//Calculamos salidas finales z
	for (k = 0; k < NEURONAS_SALIDA; k++)
	{
		entrada_z = 0;
		for (j = 0; j < NEURONAS_CAPA_OCULTA; j++)
		{
			entrada_z += Wkj[j][k] * y[j];
		}

		//Sesgo capa de salida
		entrada_z -= Wkj[NEURONAS_CAPA_OCULTA][k];

		// Valor de salida de la neurona k
		z[k] = g(entrada_z);
	}
}

void bp(double **Wji, double **Wkj, double *x, double *y, double *z, double *t)
{
	double delta_mu_k[NEURONAS_SALIDA];
	double delta_mu_j;
	double h_mu_k;
	double h_mu_j;
	int i;
	int j;
	int k;

	//************************************************
	//Actualizamos primero los pesos oculta-salida
	//************************************************
	for (k = 0; k < NEURONAS_SALIDA; k++) {
		//Calculos intermedios
		h_mu_k = 0;
		for (j = 0; j < NEURONAS_CAPA_OCULTA; j++) {
			h_mu_k += Wkj[j][k] * y[j];
		}
		h_mu_k -= Wkj[NEURONAS_CAPA_OCULTA][k]; //Sesgo

		delta_mu_k[k] = (t[k] - g(h_mu_k)) * g_derivada(h_mu_k);

		//Ajuste de los pesos que conectan la neurona de salida k con cada una de las neuronas ocultas j
		for (j = 0; j < NEURONAS_CAPA_OCULTA; j++) {
			Wkj[j][k] += EPSILON * delta_mu_k[k] * y[j];
		}

		Wkj[NEURONAS_CAPA_OCULTA][k] += EPSILON * delta_mu_k[k] * -1; //y[j] = -1 para el sesgo
	}

	//************************************************
	//Ahora se actualizan los pesos entrada-oculta
	//************************************************
	for (j = 0; j < NEURONAS_CAPA_OCULTA; j++) {
		//Calculos intermedios
		h_mu_j = 0;
		for (i = 0; i < NEURONAS_ENTRADA; i++) {
			h_mu_j += Wji[i][j] * x[i];
		}
		h_mu_j -= Wji[NEURONAS_ENTRADA][j]; // Sesgo

		delta_mu_j = 0;
		for (k = 0; k < NEURONAS_SALIDA; k++) {
			delta_mu_j += delta_mu_k[k] * Wkj[j][k];
		}
		delta_mu_j *= f_derivada(h_mu_j);

		//Ajuste de los pesos que conectan la neurona oculta j con cada una de las neuronas de entrada i
		for (i = 0; i < NEURONAS_ENTRADA; i++) {
			Wji[i][j] += EPSILON * delta_mu_j * x[i];
		}

		Wji[NEURONAS_ENTRADA][j] += EPSILON * delta_mu_j * -1; //x[i] = -1 para el sesgo
	}
}

double calcula_LMS(double **ejemplos, double **Wji, double **Wkj, int cantidad_total_ejemplos)
{
	int mu;
	int i;
	int k;
	int cantidad_ejemplos_test = (int) ((PORCENTAJE_EJEMPLOS_TEST / 100.0)
			* cantidad_total_ejemplos);
	int cantidad_ejemplos_entrenamiento = cantidad_total_ejemplos
			- cantidad_ejemplos_test;
	double *x;
	double *y;
	double *z;
	double *t;
	double error_2; //acumulado del cuadrado de los errores

	x = (double *) calloc(NEURONAS_ENTRADA, sizeof(double)); //Entradas
	y = (double *) calloc(NEURONAS_CAPA_OCULTA, sizeof(double)); //Capa oculta
	z = (double *) calloc(NEURONAS_SALIDA, sizeof(double)); //Salidas
	t = (double *) calloc(NEURONAS_SALIDA, sizeof(double)); //Salidas deseadas

	//Probamos el rendimiento de la red en los ejemplos del dataset que estan A PARTIR del ultimo ejemplo de entrenamiento
	error_2 = 0;
	for (mu = cantidad_ejemplos_entrenamiento; mu < cantidad_total_ejemplos;
			mu++) {
		//Generamos el arreglo de entrada x a partir del ejemplo indicado
		for (i = 0; i < NEURONAS_ENTRADA; i++) {
			x[i] = ejemplos[mu][i];
		}

		//Calculamos salida de la red
		calcula_salida_red(Wji, Wkj, x, y, z);

		//Generamos el vector de salidas deseadas t para este ejemplo
		memset(t, 0, sizeof(double) * NEURONAS_SALIDA);
		t[((int) ejemplos[mu][CANTIDAD_ENTRADAS_SALIDAS - 1])] = 1;

		//Acumulamos el cuadrado del error
		for (k = 0; k < NEURONAS_SALIDA; k++) {
			error_2 += pow(t[k] - z[k], 2);
		}
	}

	//Calculamos el promedio
	double error_2_medio = error_2 / (cantidad_ejemplos_test);

	free(x);
	free(y);
	free(z);
	free(t);

	return error_2_medio;
}

double calcula_rendimiento(double **ejemplos, double **Wji, double **Wkj, int cantidad_total_ejemplos, int mostrar_entradas_salidas)
{
	int mu;
	int i;
	int k;
	int cantidad_ejemplos_test = (int) ((PORCENTAJE_EJEMPLOS_TEST / 100.0)
			* cantidad_total_ejemplos);
	int cantidad_ejemplos_entrenamiento = cantidad_total_ejemplos
			- cantidad_ejemplos_test;
	double *x;
	double *y;
	double *z;
	double *t;
	int error;
	long aciertos;
	double max;
	int ejemplo;

	x = (double *) calloc(NEURONAS_ENTRADA, sizeof(double)); //Entradas
	y = (double *) calloc(NEURONAS_CAPA_OCULTA, sizeof(double)); //Capa oculta
	z = (double *) calloc(NEURONAS_SALIDA, sizeof(double)); //Salidas
	t = (double *) calloc(NEURONAS_SALIDA, sizeof(double)); //Salidas deseadas

	//Probamos el rendimiento de la red en los ejemplos del dataset que estan A PARTIR del ultimo ejemplo de entrenamiento
	aciertos = 0;
	ejemplo = 0;
	for (mu = cantidad_ejemplos_entrenamiento; mu < cantidad_total_ejemplos;
			mu++) {
		//Generamos el arreglo de entrada x a partir del ejemplo indicado
		for (i = 0; i < NEURONAS_ENTRADA; i++)
			x[i] = ejemplos[mu][i];

		//Calculamos salida de la red
		calcula_salida_red(Wji, Wkj, x, y, z);

		//Dejamos en 1 solo la salida mayor (la decision seria tomar el "comando" del robot representado por esa salida)
		max = z[0];
		for (k = 1; k < NEURONAS_SALIDA; k++) {
			if (max < z[k])
				max = z[k];
		}
		for (k = 0; k < NEURONAS_SALIDA; k++) {
			if (max != z[k])
				z[k] = 0;
			else
				z[k] = 1.0;
		}

		//Generamos el vector de salidas deseadas t para este ejemplo
		memset(t, 0, sizeof(double) * NEURONAS_SALIDA);
		t[((int) ejemplos[mu][CANTIDAD_ENTRADAS_SALIDAS - 1])] = 1;

		//Verificamos si es acierto o error y lo acumulamos
		error = 0;
		if (mostrar_entradas_salidas == 1) {
			printf("%d. z=[", ejemplo + 1);
		}

		for (k = 0; k < NEURONAS_SALIDA; k++) {
			error += round(sqrt(pow(t[k] - z[k], 2)));

			if (mostrar_entradas_salidas == 1)
				printf("%f ", z[k]);
		}

		if (mostrar_entradas_salidas == 1) {
			printf("] -- t=[");
			for (k = 0; k < NEURONAS_SALIDA; k++)
				printf("%f ", t[k]);

			printf("]\n");
			ejemplo++;
		}

		if (error == 0)
			aciertos++;
	}

	//Calculamos la tasa de aciertos
	double tasa_aciertos = ((double) aciertos) / cantidad_ejemplos_test;

	free(x);
	free(y);
	free(z);
	free(t);

	return tasa_aciertos;
}



#include "string.h"
#include "stdio.h"
#include "mlp.h"

void genera_dataset(double x[EJEMPLOS][NEURONAS_ENTRADA], double t[EJEMPLOS][NEURONAS_SALIDA])
{

}

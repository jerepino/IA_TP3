#include "stdlib.h"
#include "math.h"
#include "time.h"
#include "mlp.h"


int main(int argc, char **argv) {
	int i;
	int j;
	int k;
	int mu;
	double Wji[NEURONAS_ENTRADA + 1][NEURONAS_CAPA_OCULTA];
	double Wkj[NEURONAS_CAPA_OCULTA + 1][NEURONAS_SALIDA];
	double x[EJEMPLOS][NEURONAS_ENTRADA];
	double y[NEURONAS_CAPA_OCULTA];
	double z[NEURONAS_SALIDA];
	double t[EJEMPLOS][NEURONAS_SALIDA];

	//Inicializa los pesos con valores aleatorios en [0,1]
	for (i = 0; i <= NEURONAS_ENTRADA; i++) {
		for (j = 0; j < NEURONAS_CAPA_OCULTA; j++) {
			Wji[i][j] = ((double) (rand() % 1000000)) / 1000000;
		}
	}

	for (j = 0; j <= NEURONAS_CAPA_OCULTA; j++) {
		for (k = 0; k < NEURONAS_SALIDA; k++) {
			Wkj[j][k] = ((double) (rand() % 1000000)) / 1000000;
		}
	}

	genera_dataset(x, t);

	double error;
	for(int e = 0;e < EPOCHS; y++)
	{
		for (mu = 0; mu < EJEMPLOS - EJEMPLOS_TEST; mu++) {
			//Calculamos salida de la red
			calcula_salida_red(Wji, Wkj, x[mu], y, z);

			//Propagamos errores
			bp(Wji, Wkj, x[mu], y, z, t[mu]);
		}

		error = 0;
		for (mu = EJEMPLOS - EJEMPLOS_TEST; mu < EJEMPLOS; mu++) {
			//Calculamos salida de la red
			calcula_salida_red(Wji, Wkj, x[mu], y, z);

			// Acumula el error
			for()
			error +=
		}

		printf("Epoch %d: %f\n", e, tasa_aciertos);

	}
	printf("\n\nTest final:\n\n");

	//Bye
	return 0;
}

/*
 * mlp.h
 *
 *  Created on: May 24, 2018
 *      Author: martin
 */

#ifndef MLP_H_
#define MLP_H_

#define NEURONAS_ENTRADA 4
#define NEURONAS_CAPA_OCULTA 15
#define NEURONAS_SALIDA 4
#define PORCENTAJE_EJEMPLOS_TEST 5.0
#define EPSILON 0.3
#define EJEMPLOS 1000
#define EJEMPLOS_TEST 100
#define EPOCHS 10000

void calcula_salida_red(double **Wji, double **Wkj, double *x, double *y, double *z);
void bp(double **Wji, double **Wkj, double *x, double *y, double *z, double *t);
double calcula_LMS(double **ejemplos, double **Wji, double **Wkj, int cantidad_total_ejemplos);
double calcula_rendimiento(double **ejemplos, double **Wji, double **Wkj, int cantidad_total_ejemplos, int mostrar_entradas_salidas);

#endif /* MLP_H_ */
